//onEvents('ricipes',event=>{
StartupEvents.registry('block', event => {
    event.create("cracked_deepslate") .hardness(1.0) .tagBlock("mineable/pickaxe") .requiresTool(true);
})

StartupEvents.registry('item', event => {
    event.create("molten_deepslate") .tooltip('A hot clump of deepslate');
})

StartupEvents.registry('fluid', event => {
    event.create("molten_lead")
    .bucketColor(0x8d78a6)
    .thickTexture(0x8d78a6);
})

StartupEvents.registry('fluid', event => {
    event.create("liquified_gold")
    .bucketColor(0xded879)
    .thinTexture(0xded879);
})