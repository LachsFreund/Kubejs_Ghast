//onEvents('ricipes',event=>{
StartupEvents.registry('block', event => {
    event.create("cracked_deepslate") .hardness(1.0) .tagBlock("mineable/pickaxe") .requiresTool(true);
})

StartupEvents.registry('item', event => {
    event.create("molten_deepslate") .tooltip('A hot clump of deepslate');
})

StartupEvents.registry('fluid', event => {
    event.create("molten_lead")
    .bucketColor(0x8d78a6)
    .thickTexture(0x8d78a6);
})

StartupEvents.registry('fluid', event => {
    event.create("liquified_gold")
    .bucketColor(0xded879)
    .thinTexture(0xded879);
})

// T400
StartupEvents.registry('fluid', event => {
    event.create("liquid_t_400")
    .bucketColor(0xff7f00)
    .thinTexture(0xff7f00);
})

StartupEvents.registry('item', event => {
    event.create("bottle_of_t400").food(food => {
        food
        .hunger(20)
        .saturation(200)
        .effect("speed", 100,0,1)
        .alwaysEdible()
    })
})