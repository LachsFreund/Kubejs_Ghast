ServerEvents.recipes(event => {
    event.custom({
        type: "create:mixing",
        heatRequirement: "heated",
        ingredients: [
            { item: "create_tank_defenses:iron_dust" },
            { item: "create_tank_defenses:coke_coal" },
        ],
        results: [
            { item: "crusty_chunks:steel_ingot" }
        ]
    })
})