// steel ingot
ServerEvents.recipes(event => {
    event.custom({
        type: "create:mixing",
        heatRequirement: "heated",
        ingredients: [
            { item: "create_tank_defenses:iron_dust" },
            { item: "create_tank_defenses:coke_coal" },
        ],
        results: [
            { item: "crusty_chunks:steel_ingot" }
        ]
    })
})
// iron dust
ServerEvents.recipes(event => {
    event.remove({ output: 'create_tank_defenses:iron_dust', type: 'create:crushing' })
    event.remove({ output: 'create_tank_defenses:iron_dust', type: 'create:milling' })

    event.custom({
        type: "create:crushing",
        ingredients: [
            { item: "minecraft:iron_ingot" },
        ],
        results: [
            { item: "create_tank_defenses:iron_dust", count: 2 }
        ]
    })
    event.custom({
        type: "create:milling",
        ingredients: [
            { item: "minecraft:iron_ingot" },
        ],
        results: [
            { item: "create_tank_defenses:iron_dust", count: 2 }
        ]
    })
})