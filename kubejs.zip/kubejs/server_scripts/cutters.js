ServerEvents.recipes(event => {
    // Deploying cutters
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:copper_plate" },
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:copper_wire" }
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:steelplate" },
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:steel_wire" }
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:bent_component" },
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:cut_component" }
        ]
    })
})