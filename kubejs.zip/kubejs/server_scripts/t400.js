ServerEvents.recipes(event => {
    event.custom({
        type: "create:mixing",
        ingredients: [
            { item: "minecraft:sugar"},
            { item: "minecraft:redstone"},
            { item: "minecraft:iron_ingot"},
            { fluid: "minecraft:lava", amount: 1000 },
            { fluid: "minecraft:water", amount: 1000 }
        ],
        results: [
            { fluid: "kubejs:liquid_t_400", amount: 1000 }
        ]
    })
    // t400 bottle
    event.custom({
        type: "create:filling",
        ingredients: [
            { item: "minecraft:glass_bottle"},
            { fluid: "kubejs:liquid_t_400", amount: 250}
        ],
        results: [
            { item: "kubejs:bottle_of_t400"}
        ]
    })
})