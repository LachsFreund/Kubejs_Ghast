ServerEvents.recipes(event => {
    // Crushing Gold to Gold Dust
    event.custom({
        type: "create:crushing",
        ingredients: [
            { item: "minecraft:gold_ingot" }
        ],
        results: [
            { item: "crusty_chunks:gold_dust", count: 2 }
        ]
    })
    // Milling Gold to Gold Dust
    event.custom({
        type: "create:milling",
        ingredients: [
            { item: "minecraft:gold_ingot" }
        ],
        processingTime: 200,
        results: [
            { item: "crusty_chunks:gold_dust", count: 2 }
        ]
    })
    // Mixing Water and Gold Dust to Liquified Gold
    event.custom({
        type: "create:mixing",
        ingredients: [
            { item: "crusty_chunks:gold_dust" },
            {fluid: "minecraft:water", amount: 50 }
        ],
        results: [
            { fluid: "kubejs:liquified_gold", amount: 250 }
        ]
    })
    // Heated Mixing Liquified Gold and Cobblestone to Sulfur Ore
    event.custom({
        type: "create:mixing",
        heatRequirement: "heated",
        ingredients: [
            { fluid: "kubejs:liquified_gold", amount: 250 },
            { item: "minecraft:cobblestone"}
        ],
        results: [
            { item: "crusty_chunks:sulfur_ore", amount: 4 }
        ]
    })
    // Crushing Sulfur Ore to Sulfur
    event.custom({
        type: "create:crushing",
        ingredients: [
            { item: "crusty_chunks:sulfur_ore"}
        ],
        results: [
            { item: "crusty_chunks:sulfur"}
        ]
    })
    // Milling Sulfur Ore to Sulfur
    event.custom({
        type: "create:milling",
        ingredients: [
            { item: "crusty_chunks:sulfur_ore"}
        ],
        processingTime: 200,
        results: [
            { item: "crusty_chunks:sulfur"}
        ]
    })
})