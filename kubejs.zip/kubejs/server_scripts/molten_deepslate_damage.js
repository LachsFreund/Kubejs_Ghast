let moltenTimer = 0

ServerEvents.tick(event => {
    moltenTimer++

    if (moltenTimer >= 100) { // Every 5 seconds
        moltenTimer = 0

        event.server.players.forEach(player => {
            if (player.inventory.contains(Item.of('kubejs:molten_deepslate'))) {
                
                // Deal damage
                player.attack(2.0)

                const pos = player.position()

                // Spawn flame and smoke particles
                for (let i = 0; i < 5; i++) {
                    player.level.spawnParticle("flame", pos.x + (Math.random() - 0.5), pos.y + 1.0, pos.z + (Math.random() - 0.5), 0, 0.05, 0)
                    player.level.spawnParticle("smoke", pos.x + (Math.random() - 0.5), pos.y + 1.0, pos.z + (Math.random() - 0.5), 0, 0.02, 0)
                }

                // Play lava item burn sound
                player.level.playSound(null, pos.x, pos.y, pos.z, 'minecraft:entity.item.burn', player.getSoundSource(), 1.0, 1.0)

            }
        })
    }
})