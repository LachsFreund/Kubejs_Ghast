ServerEvents.recipes(event => {
    // Eisen and copper nugget to raw aluminium
    event.custom({
        type: "create:compacting",
        ingredients: [
            { item: "minecraft:iron_ingot" },
            { item: "minecraft:iron_ingot" },
            { item: "create:copper_nugget"},
            { item: "create:copper_nugget"}
        ],
        results: [
            { item: "crusty_chunks:aluminum_dust"}
        ]
    })
})