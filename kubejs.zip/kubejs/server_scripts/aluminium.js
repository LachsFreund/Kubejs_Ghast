ServerEvents.recipes(event => {
    // Iron and copper nugget to raw aluminium
    event.custom({
        type: "create:compacting",
        ingredients: [
            { item: "minecraft:iron_ingot" },
            { item: "create:copper_nugget"}
        ],
        results: [
            { item: "crusty_chunks:aluminum_dust", count: 2 }
        ]
    })
})