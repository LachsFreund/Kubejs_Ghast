ServerEvents.recipes(event => {
    // lerge barrel
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:large_unbored_barrel"},
            { item: "minecraft:lightning_rod"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:large_bored_barrel"}
        ]
    })
    //component
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:cast_component"},
            { item: "minecraft:lightning_rod"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:bored_component"}
        ]
    })
    //tube
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:steel_cylinder"},
            { item: "minecraft:lightning_rod"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:steel_tube"}
        ]
    })
})