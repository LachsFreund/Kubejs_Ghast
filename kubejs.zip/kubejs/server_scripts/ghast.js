ServerEvents.recipes(event => {
  event.shaped({
    type: "minecraft:crafting_shaped",
    category: "misc", 
    key: { 
        "A": { item: "minecraft:ghast_tear" },
        "B": { item: "minecraft:soul_sand" }
        },
        pattern: [
        "AAA",
        "ABA",
        "AAA"
        ],
        result: 
        { item: "dried_ghast:dried_ghast", count: 1 }
    })
})