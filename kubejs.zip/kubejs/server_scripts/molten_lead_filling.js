// File: kubejs/server_scripts/molten_lead.js

// Register Fluid and Bucket Item
ServerEvents.highPriorityData(event => {
    
    // Fluid
    event.addJson('kubejs:fluid/molten_lead', {
        "forge:fluid": {
            "still_texture": "kubejs:block/molten_lead_still",
            "flowing_texture": "kubejs:block/molten_lead_flow",
            "bucket_color": 0xCCCCCC,
            "display_name": "Molten Lead",
            "thick": true,
            "bucket_item": "kubejs:molten_lead_bucket"
        }
    })
})

// Create Filling Recipe for Bucket
ServerEvents.recipes(event => {
    event.custom({
        type: 'create:filling',
        ingredients: [
            { item: 'minecraft:bucket' },
            { fluid: 'kubejs:molten_lead', amount: 1000 }
        ],
        results: [
            { item: 'kubejs:molten_lead_bucket' }
        ]
    })

    // Optional: Emptying Recipe to get fluid back
    event.custom({
        type: 'create:emptying',
        ingredients: [
            { item: 'kubejs:molten_lead_bucket' }
        ],
        results: [
            { item: 'minecraft:bucket' },
            { fluid: 'kubejs:molten_lead', amount: 1000 }
        ]
    })
})
