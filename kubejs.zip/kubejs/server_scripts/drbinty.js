ServerEvents.recipes(event => {
    event.custom({
        type: "create:mixing",
        ingredients: [
            { item: "minecraft:sugar"},
            { item: "minecraft:redstone"},
            { item: "minecraft:iron_nugget"},
            { fluid: "minecraft:honey", amount: 250 },
            { fluid: "minecraft:water", amount: 1000 }
        ],
        results: [
            { fluid: "kubejs:drbinty", amount: 1000 }
        ]
    })

    event.custom({
        type: "create:filling",
        ingredients: [
            { item: "minecraft:glass_bottle"},
            { fluid: "kubejs:drbinty", amount: 250}
        ],
        results: [
            { item: "kubejs:drbinty_bottle"}
        ]
    })
})