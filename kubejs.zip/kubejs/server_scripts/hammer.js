ServerEvents.recipes(event => {
    // Pressing items
    event.custom({
        type: "create:pressing",
        ingredients: [
            { item: "crusty_chunks:copper_wire" }
        ],
        results: [
            { item: "crusty_chunks:copper_coil" }
        ]
    })

    event.custom({
        type: "create:pressing",
        ingredients: [
            { tag: "forge:ingots/steel" }
        ],
        results: [
            { item: "crusty_chunks:steelplate" }
        ]
    })

    event.custom({
        type: "create:pressing",
        ingredients: [
            { tag: "forge:ingots/brass" }
        ],
        results: [
            { item: "crusty_chunks:brass_plate" }
        ]
    })

    event.custom({
        type: "create:pressing",
        ingredients: [
            { item: "minecraft:copper_ingot" }
        ],
        results: [
            { item: "crusty_chunks:copper_plate" }
        ]
    })

    event.custom({
        type: "create:pressing",
        ingredients: [
            { item: "crusty_chunks:aluminum_ingot" }
        ],
        results: [
            { item: "crusty_chunks:aluminum_plate" }
        ]
    })

    event.custom({
        type: "create:pressing",
        ingredients: [
            { item: "crusty_chunks:steel_wire" }
        ],
        results: [
            { item: "crusty_chunks:steel_spring" }
        ]
    })

    event.custom({
        type: "create:pressing",
        ingredients: [
            { item: "crusty_chunks:steel_plate" }
        ],
        results: [
            { item: "crusty_chunks:bent_component" }
        ]
    })
})