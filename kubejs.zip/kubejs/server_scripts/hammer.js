ServerEvents.recipes(event => {
    // Copper coil
    event.custom({
        type: "create:pressing",
        ingredients: [
            { item: "crusty_chunks:copper_wire" }
        ],
        results: [
            { item: "crusty_chunks:copper_coil" }
        ]
    })
    // steel plate
    event.custom({
        type: "create:pressing",
        ingredients: [
            { tag: "forge:ingots/steel" }
        ],
        results: [
            { item: "crusty_chunks:steelplate" }
        ]
    })
    // aluminum plate
    event.custom({
        type: "create:pressing",
        ingredients: [
            { item: "crusty_chunks:aluminum_ingot" }
        ],
        results: [
            { item: "crusty_chunks:aluminum_plate" }
        ]
    })
    // steel spring
    event.custom({
        type: "create:pressing",
        ingredients: [
            { item: "crusty_chunks:steel_wire" }
        ],
        results: [
            { item: "crusty_chunks:steel_spring" }
        ]
    })
    // bent components
    event.custom({
        type: "create:pressing",
        ingredients: [
            { item: "crusty_chunks:steel_plate" }
        ],
        results: [
            { item: "crusty_chunks:bent_component" }
        ]
    })
})