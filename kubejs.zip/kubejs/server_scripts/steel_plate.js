ServerEvents.recipes(event => {
  event.remove({ output: 'create_tank_defenses:steel_sheet', type: 'create:pressing' })
})

ServerEvents.recipes(event => {
    event.shaped({
        type: "minecraft:crafting_shaped",
    "category": "misc", 
    "key": { 
        "A": { item: "crusty_chunks:steelplate" },
        "B": { item: "minecraft:spruce_log" }
        },
        pattern: [
        " A ",
        "ABA",
        " A "
        ],
        result: 
        { item: "create_tank_defenses:steel_casing", count: 1 }
    })
})