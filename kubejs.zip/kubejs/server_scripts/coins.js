ServerEvents.recipes(event => {
  event.remove({ output: 'create_tank_defenses:incomplete_boiling_mechanism_phase_one', type: 'create:pressing' })
  event.remove({ output: 'create_tank_defenses:incomplete_capacitor_mechanism_phase_one', type: 'create:pressing' })
})