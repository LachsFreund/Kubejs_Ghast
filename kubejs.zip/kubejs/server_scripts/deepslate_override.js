ServerEvents.recipes(event => {
  event.remove({ output: 'minecraft:deepslate', type: 'create:compacting' })
  // Add a new, cheaper version: 4 cobblestone + 100mb water
  event.custom({
    type: 'create:compacting',
    ingredients: [
      { item: 'minecraft:flint' },
      { item: 'minecraft:flint' },
      { item: 'minecraft:flint' },
      { item: 'minecraft:flint' },
      { fluid: 'minecraft:lava', amount: 50 }
    ],
    results: [
      { item: 'minecraft:deepslate' }
    ]
  })
})