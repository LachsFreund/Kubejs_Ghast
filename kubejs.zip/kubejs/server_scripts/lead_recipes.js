ServerEvents.recipes(event => {
    // Pressing Deepslate zu Cracked Deepslate
    event.custom({
        type: "create:pressing",
        ingredients: [
            { item: "minecraft:deepslate" }
        ],
        results: [
            { item: "kubejs:cracked_deepslate" }
        ]
    })
    // Mixing Cracked Deepslate zu Molten Deepslate
    event.custom({
        type: "create:mixing",
        heatRequirement: "heated",
        ingredients: [
            { item: "kubejs:cracked_deepslate" }
        ],
        results: [
            { item: "kubejs:molten_deepslate", amount: 1 }
        ]
    })
    // Mixing Molten Deepslate + Lava zu Molten Lead (als Fluid)
    event.custom({
        type: "create:mixing",
        ingredients: [
            { item: "kubejs:molten_deepslate" },
            { fluid: "minecraft:lava", amount: 250 }
        ],
        results: [
            { fluid: "kubejs:molten_lead", amount: 1000 }
        ]
    })
    // Compacting Molten Lead zu Lead Ingot
    event.custom({
        type: "create:compacting",
        ingredients: [
            { fluid: "kubejs:molten_lead", amount: 500 }
        ],
        results: [
            { item: "crusty_chunks:lead_ingot",amount: 1 }
        ]
    })
    // Crushing Lead to Dust
    event.custom({
        type: "create:crushing",
        ingredients: [
            { item: "crusty_chunks:lead_ingot"}
        ],
        results: [
            { item: "crusty_chunks:lead_dust", count: 2 }
        ]
    })
    // Milling Lead to Dust
    event.custom({
        type: "create:milling",
        ingredients: [
            { item: "crusty_chunks:lead_ingot"}
        ],
        processingTime: 200,
        results: [
            { item: "crusty_chunks:lead_dust", count: 2 }
        ]
    })
})