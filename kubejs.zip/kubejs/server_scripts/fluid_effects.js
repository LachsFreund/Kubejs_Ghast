ServerEvents.tick(event => {
  const players = event.server.players;

  players.forEach(player => {
    const block = player.level.getBlock(player.blockX, player.blockY, player.blockZ);

    // Check if the block at the player's feet is lava
    if (block.id === 'kubejs:molten_lead') {
      // Set player on fire for 4 seconds (80 ticks)
      player.setSecondsOnFire(4);
    }
  });

  players.forEach(player => {
    const block = player.level.getBlock(player.blockX, player.blockY, player.blockZ);

    // Check if the block at the player's feet is lava
    if (block.id === 'kubejs:liquified_gold') {
      // Makes the player glow
      player.potionEffects.add('minecraft:glowing', 100, 1, false, false);
    }
  });
});