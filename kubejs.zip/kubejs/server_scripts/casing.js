ServerEvents.recipes(event => {
    // large casings
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "create:brass_sheet", count: 3},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:large_casing", count: 16 }
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:brass_plate", count: 3},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:large_casing", count: 16 }
        ]
    })
})

