ServerEvents.recipes(event => {
    // small casings
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "create:brass_sheet"},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:small_casing", count: 32 }
        ]
    })
    
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:brass_plate"},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:small_casing", count: 32 }
        ]
    })
    
    // medium casings
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "create:brass_sheet", count: 2},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:medium_casing", count: 16 }
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:brass_plate", count: 2},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:medium_casing", count: 16 }
        ]
    })

    // large casings
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "create:brass_sheet", count: 3},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:large_casing", count: 16 }
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:brass_plate", count: 3},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:large_casing", count: 16 }
        ]
    })

    // extra large casings
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "create:brass_sheet", count: 4},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:extra_large_casing", count: 10 }
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:brass_plate", count: 4},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:extra_large_casing", count: 10 }
        ]
    })

    // huge casings
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "create:brass_sheet", count: 6},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:huge_casing", count: 12 }
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "crusty_chunks:brass_plate", count: 6},
            { item: "crusty_chunks:cutters"}
        ],
        keepHeldItem: true,
        results: [
            { item: "crusty_chunks:huge_casing", count: 12 }
        ]
    })
})

