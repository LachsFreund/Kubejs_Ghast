ServerEvents.recipes(event => {
  // Remove the old tuff recipe (compacting with 16 cobblestone + water)
  event.remove({ output: 'minecraft:tuff', type: 'create:compacting' })

  // Add a new, cheaper version: 4 cobblestone + 100mb water
  event.custom({
    type: 'create:compacting',
    ingredients: [
      { item: 'minecraft:cobblestone' },
      { item: 'minecraft:cobblestone' },
      { item: 'minecraft:cobblestone' },
      { item: 'minecraft:cobblestone' },
      {
        fluid: 'minecraft:water',
        amount: 100
      }
    ],
    results: [
      { item: 'minecraft:tuff' }
    ]
  })

  event.remove({ type: 'create:crushing', input: 'minecraft:tuff' })

  // Add new crushing recipe with 35% chance for all outputs
  event.custom({
    type: "create:crushing",
    ingredients: [
      { item: "minecraft:tuff" }
    ], 
    processingTime: 200,
    results: [
      { item: 'minecraft:flint', chance: 0.50 },
      { item: 'minecraft:gold_nugget', chance: 0.35 },
      { item: 'create:copper_nugget', chance: 0.35 },
      { item: 'create:zinc_nugget', chance: 0.35 },
      { item: 'minecraft:iron_nugget', chance: 0.35 },
    ]
  })
})