ServerEvents.recipes(event => {
  // Remove the old tuff recipe (compacting with 16 cobblestone + water)
  event.remove({ output: 'minecraft:tuff', type: 'create:compacting' })

  // Add a new, cheaper version: 4 cobblestone + 100mb water
  event.custom({
    type: 'create:compacting',
    ingredients: [
      { item: 'minecraft:cobblestone' },
      { item: 'minecraft:cobblestone' },
      { item: 'minecraft:cobblestone' },
      { item: 'minecraft:cobblestone' },
      {
        fluid: 'minecraft:water',
        amount: 100
      }
    ],
    results: [
      { item: 'minecraft:tuff' }
    ]
  })
})
